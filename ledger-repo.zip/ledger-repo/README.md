# The Ledger — daily auto-updating share briefings

This turns your watchlist into a real website that updates itself every day,
using a free GitHub Actions schedule (no server of your own needed).

## What's in this folder
- `watchlist.json` — the tickers you're tracking. Edit this to add/remove shares.
- `scripts/fetch_briefings.py` — pulls free news headlines and price history,
  then asks Gemini (free tier) to write a balanced summary and pros/cons.
- `.github/workflows/daily.yml` — the schedule that runs the script automatically.
- `data/briefings.json` — the results. The website reads this file.
- `index.html` — the public website.

## One-time setup (about 10 minutes)

### 1. Create a GitHub account
Go to https://github.com/join and sign up (free).

### 2. Create a new repository
- Click the "+" in the top right → "New repository"
- Name it anything, e.g. `the-ledger`
- Set it to **Public** (required for free GitHub Pages)
- Click "Create repository"

### 3. Upload these files
On the new repo's page, click "uploading an existing file" and drag in
**all the files and folders from this package**, keeping the folder structure
(`.github/workflows/daily.yml`, `scripts/fetch_briefings.py`, `data/briefings.json`,
`watchlist.json`, `index.html`). Commit the upload.

### 4. Get a free Gemini API key
- Go to https://aistudio.google.com/apikey
- Sign in with a Google account, click **Create API key** — instant, free, no card.

### 5. Add the key as a GitHub secret
- In the repo, go to **Settings → Secrets and variables → Actions**
- Click **New repository secret**
- Name: `GEMINI_API_KEY`
- Value: paste the key from step 4
- Save

### 6. Turn on GitHub Pages
- Go to **Settings → Pages**
- Under "Build and deployment", set Source to **Deploy from a branch**
- Branch: `main`, folder: `/ (root)`
- Save. GitHub will give you a URL like `https://yourname.github.io/the-ledger/`
  — that's your live site.

### 7. Run the workflow once manually
- Go to the **Actions** tab → click **Daily share briefing** → **Run workflow**
- This does the first fetch immediately instead of waiting for the schedule.
- After it finishes (~1-2 minutes), refresh your Pages URL — you should see
  briefings for AAPL and MSFT (the default watchlist).

## Day to day
- The workflow runs automatically every day at 06:00 UTC (edit the `cron` line
  in `daily.yml` to change the time).
- To change your watchlist, edit `watchlist.json` in the repo (or via the
  GitHub web editor — click the pencil icon on the file) and commit. The next
  scheduled run (or a manual "Run workflow") will pick up the new list.
- The site at your Pages URL always shows the latest committed `data/briefings.json`.

## Notes
- This uses a free Gemini API key, so there's no cost for normal watchlist
  sizes (Gemini's free tier covers well over the handful of daily requests
  this needs).
- The AI summary is based on recent headlines, not live web search — quality
  depends on how much news exists for a given ticker that day. Thinly-covered
  tickers may get a thinner summary.
- If a ticker fails (bad symbol, no headlines found), it'll show an error on
  the site instead of breaking the whole run.
- Price history (a 30-day sparkline chart on each ticket) is pulled for free
  from Stooq, no API key needed. If a ticker's price can't be found there,
  the briefing still shows — just without a chart.
