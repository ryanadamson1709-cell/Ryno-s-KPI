import csv
import io
import json
import os
import re
import sys
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime, timezone

GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY")
GEMINI_URL = (
    "https://generativelanguage.googleapis.com/v1beta/models/"
    "gemini-2.0-flash:generateContent?key={key}"
)

WATCHLIST_FILE = "watchlist.json"
OUTPUT_FILE = "data/briefings.json"


def get_price_history(ticker, days=30):
    """Fetch recent daily closes from Stooq (free, no API key required)."""
    candidates = [ticker.lower()]
    if "." not in ticker:
        candidates.append(ticker.lower() + ".us")

    for candidate in candidates:
        url = f"https://stooq.com/q/d/l/?s={candidate}&i=d"
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=30) as resp:
                raw = resp.read().decode("utf-8")
            if "Date,Open,High,Low,Close" not in raw:
                continue
            reader = csv.DictReader(io.StringIO(raw))
            rows = [r for r in reader if r.get("Close") not in (None, "", "N/D")]
            if not rows:
                continue
            rows = rows[-days:]
            return {
                "dates": [r["Date"] for r in rows],
                "closes": [round(float(r["Close"]), 4) for r in rows],
            }
        except Exception:
            continue
    return None


def get_headlines(ticker, limit=8):
    """Fetch recent headlines for a ticker from Google News RSS (free, no key)."""
    query = urllib.parse.quote(f"{ticker} stock")
    url = f"https://news.google.com/rss/search?q={query}&hl=en-US&gl=US&ceid=US:en"
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=30) as resp:
            raw = resp.read()
        root = ET.fromstring(raw)
        items = root.findall("./channel/item")[:limit]
        headlines = []
        for item in items:
            title = item.findtext("title") or ""
            link = item.findtext("link") or ""
            source_el = item.find("source")
            source = source_el.text if source_el is not None else ""
            headlines.append({"title": title, "link": link, "source": source})
        return headlines
    except Exception as e:
        print(f"  headline fetch failed for {ticker}: {e}", file=sys.stderr)
        return []


def summarize_with_gemini(ticker, headlines):
    if not GEMINI_API_KEY:
        raise RuntimeError("GEMINI_API_KEY environment variable is not set.")
    if not headlines:
        raise RuntimeError("No headlines found to summarize.")

    headlines_text = "\n".join(
        f"- {h['title']} ({h['source']})" for h in headlines
    )

    prompt = f"""You are a financial news analyst. Below are recent headlines about the
stock with ticker "{ticker}". Based ONLY on these headlines, write a balanced briefing.

Headlines:
{headlines_text}

Respond with ONLY a raw JSON object, no markdown fences, no preamble, matching exactly:
{{
  "company_name": "full company name if identifiable from the headlines, else the ticker",
  "summary": "2-3 sentence neutral summary of what's happening with this share, in your own words",
  "pros": ["3-5 short bullet points, positive factors implied by the headlines, each under 18 words"],
  "cons": ["3-5 short bullet points, negative factors or risks implied by the headlines, each under 18 words"]
}}

If the headlines are too thin or unrelated to draw conclusions, say so plainly in the summary
and return shorter pros/cons lists rather than inventing information. Output nothing but the JSON object."""

    body = json.dumps({
        "contents": [{"parts": [{"text": prompt}]}]
    }).encode("utf-8")

    req = urllib.request.Request(
        GEMINI_URL.format(key=GEMINI_API_KEY),
        data=body,
        headers={"Content-Type": "application/json"},
        method="POST",
    )

    with urllib.request.urlopen(req, timeout=60) as resp:
        data = json.loads(resp.read().decode("utf-8"))

    text = (
        data.get("candidates", [{}])[0]
        .get("content", {})
        .get("parts", [{}])[0]
        .get("text", "")
    ).strip()

    text = re.sub(r"^```json\s*", "", text, flags=re.IGNORECASE)
    text = re.sub(r"```$", "", text.strip())

    start = text.find("{")
    end = text.rfind("}")
    if start == -1 or end == -1:
        raise ValueError(f"No JSON object found in model output: {text[:200]}")

    return json.loads(text[start:end + 1])


def main():
    with open(WATCHLIST_FILE, "r") as f:
        watchlist = json.load(f)

    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")

    if os.path.exists(OUTPUT_FILE):
        with open(OUTPUT_FILE, "r") as f:
            briefings = json.load(f)
    else:
        briefings = {}

    for ticker in watchlist:
        ticker = ticker.strip().upper()
        print(f"Researching {ticker}...")
        price = get_price_history(ticker)
        headlines = get_headlines(ticker)

        try:
            parsed = summarize_with_gemini(ticker, headlines)
            sources = [
                {"name": h["source"] or h["title"], "url": h["link"]}
                for h in headlines
            ]
            briefings[ticker] = {
                "date": today,
                "company_name": parsed.get("company_name", ticker),
                "summary": parsed.get("summary", ""),
                "pros": parsed.get("pros", []),
                "cons": parsed.get("cons", []),
                "sources": sources,
                "price_history": price,
            }
            print(f"  OK: {ticker}")
        except Exception as e:
            print(f"  FAILED: {ticker}: {e}", file=sys.stderr)
            briefings[ticker] = {
                "date": today,
                "error": str(e),
                "price_history": price,
            }

    watchlist_upper = {t.strip().upper() for t in watchlist}
    briefings = {k: v for k, v in briefings.items() if k in watchlist_upper}

    os.makedirs(os.path.dirname(OUTPUT_FILE), exist_ok=True)
    with open(OUTPUT_FILE, "w") as f:
        json.dump({"updated": today, "briefings": briefings}, f, indent=2)

    print("Done.")


if __name__ == "__main__":
    main()
